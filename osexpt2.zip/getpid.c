#include<stdio.h>
#include<unistd.h>
int main()
{
	int n=fork();
	if(n>0)
		printf("Parent process id is %d\n",getpid());
	else
	{
		printf("Child process id is %d\n",getpid());
		printf("Parent process id is %d\n",getppid());
	}
	return 0;
}

