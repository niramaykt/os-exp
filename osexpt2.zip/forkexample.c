#include<stdio.h>
#include<unistd.h>
void forkexample()
{
	int x=1;
	if(fork()==0)
		printf("Child process has x=%d\n",++x);
	else
		printf("Parent process has x=%d\n",--x);
}
void main()
{
	forkexample();
}
