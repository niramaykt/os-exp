#include<stdio.h>
#include<unistd.h>
void forkexample()
{
	int x=1;
	if(fork()==0)
		printf("Child process %d has x=%d\n",getpid(),++x);
	else
		printf("Parent process %d has x=%d\n",getpid(),--x);
}
void main()
{
	forkexample();
}
