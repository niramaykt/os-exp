import os
cmd="ls"
ret_op=os.system(cmd)
print("Output is ",ret_op)
