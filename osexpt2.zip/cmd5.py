import subprocess
cmd="date"
ret_op=subprocess.call(cmd,shell=True)
print("Output is ",ret_op)
